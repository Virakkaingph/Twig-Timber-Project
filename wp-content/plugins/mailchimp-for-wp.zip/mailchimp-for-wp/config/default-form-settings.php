<?php
return array(
	'css' => 0,
	'double_optin' => 1,
	'hide_after_success' => 0,
	'lists' => array(),
	'redirect' => '',
	'replace_interests' => 1,
	'required_fields' => '',
	'send_welcome' => 0,
	'update_existing' => 0,
);
