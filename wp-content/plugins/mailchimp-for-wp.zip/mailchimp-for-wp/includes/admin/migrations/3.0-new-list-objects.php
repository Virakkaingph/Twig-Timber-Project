<?php

defined( 'ABSPATH' ) or exit;

delete_transient( 'mc4wp_mailchimp_lists' );
delete_transient( 'mc4wp_mailchimp_lists_fallback' );