<?php
if ( ! is_admin() ) { die( 'Access denied.' ); }
// Server info page extended PHPinfo thickbox.

/* phpinfo()
 *
 * Server info page phpinfo button.
 *
 */

phpinfo();
die();