=== AJC Network Plugin ===

Contributors: Belief
Tags: restrict, non-admin, user, user role, prevent, limit, new page, remove, stop, hide, disable, add new, page
Requires at least: 2.7
Tested up to: 3.7.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Add functionality specific to the A Jesus Church network site.


== Installation ==

1. Download the ajc-network.zip file
2. Upload and extract the contents of ajc-network.zip to your wp-content/plugins/folder
3. Activate the AJC Network Plugin in your WP-admin
4. Done!
