<?php defined( 'ABSPATH' ) or exit; ?>
<div id="missing-fields-notice" class="mc4wp-notice" style="display: none; margin-top: 20px;">
	<p>
		<?php echo __( 'Your form is missing the following (required) form fields:', 'mailchimp-for-wp' ); ?>
	</p>
	<ul id="missing-fields-list" class="ul-square"></ul>
</div>