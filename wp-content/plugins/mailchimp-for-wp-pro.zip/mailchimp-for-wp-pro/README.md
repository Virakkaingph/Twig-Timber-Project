# MailChimp for WordPress Pro

__Stable Version:__ 2.7.17

Not sure how to install this plugin? Take a look at the installation guide linked below. 

Installation Guide: https://mc4wp.com/kb/installation-instructions/
Documentation: https://mc4wp.com/kb/

Hope you enjoy this plugin!

Danny, Ines & Harish
[mc4wp.com](https://mc4wp.com)