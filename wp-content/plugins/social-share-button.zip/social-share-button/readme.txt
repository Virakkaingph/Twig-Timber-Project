=== Social Share Button ===
Contributors: projectW
Donate link: 
Tags: social share buttons, social share button, share button, social share, social share plugin, share plugin, social share plugin wordpress, Social Media Plugins, Social Media share
Requires at least: 3.8
Tested up to: 4.0
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Social share buttons display on post or page or custom post

== Description ==

Displaying social share button on your website is most powerful way to boost your website traffic and visitors from social media sites, best way to recommend website content to social media friends.

<strong>Social Share Button</strong> is one of best plugin to display social share buttons on your website easy to manage and customizing vai settings page.

<strong>Plugin Features</strong>

* 7 Different themes.
* Display hover style sidebar.
* default social share buttons.
* Display top or bellow content.
* margin for buttons.
* share count for custom social share.




== Installation ==


1. Install as regular WordPress plugin.
2. Go your Pluings setting via WordPress Dashboard and <strong>activate</strong> it.
3. After Activate you see Menu on left Sidebar "<strong>SSB Settings</strong>" 

if you are first time change settings and hit <strong>"Save Changes"</strong>

and visit your website or single post.

== Screenshots ==

1. Flat Style.
2. Rounded Style.
3. Wide Style.
4. Pack Slide Style.
5. Pack Style.
5. Hexa Style.

== Changelog ==

= 1.5 =
* Add pin button for defualt share buttons.


= 1.4 =
* Update admin settings.
* Two theme added for social buttons.

= 1.3 =
* filter posttype to display share buttons.
* Fixed admin settings.
* Open share window on new or same tab.

= 1.2 =
* Bug Fixed.

= 1.1 =
* added share count.

= 1.0 =
* Initial release

