/*
 * Ajax Forms
 */
/*var $context;

// jQuery.ajaxForm is undefined, bail.
if( $.fn.ajaxForm === undefined ) {
	console.log( 'MailChimp for WP: jquery-forms.js is not loaded properly. Not activating AJAX.');
	return false;
}

$('.newsletter form').ajaxForm({
	data: { action: 'mc4wp_submit_form' },
	dataType: 'json',
	url: 'get_the_url', // mc4wp_vars.ajaxurl,
	delegation: true,
	success: function (response, status) {

	},
	error: function (response) {
		console.log(response);
	},
	beforeSubmit: function (data, $form) {
		var $submitButton;

		// $ajaxLoader = $context.find('.mc4wp-ajax-loader');
		$submitButton = $form.find('input[type=submit]');

		return true;
	}
});*/
